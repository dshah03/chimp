module.exports = require('./toPairs');
