
* allow cucumber `name` option to run specific scenarios (tiagolr) 
* Adds the release notes for v0.49.1 (Lukasz Gandecki) 

